namespace Zoo.Domain.Enums;

public enum HealthStatus
{
    Healthy,
    Sick
}