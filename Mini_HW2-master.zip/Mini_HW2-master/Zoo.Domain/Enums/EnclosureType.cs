namespace Zoo.Domain.Enums;

public enum EnclosureType
{
    Predator,
    Herbivore,
    Aviary,
    Aquarium,
    ReptileHouse,
    Other
}