namespace Zoo.Domain.Enums;

public enum Gender
{
    Male,
    Female,
    Unknown
}