namespace Zoo.Domain.Interfaces;

public interface IDomainEvent { }