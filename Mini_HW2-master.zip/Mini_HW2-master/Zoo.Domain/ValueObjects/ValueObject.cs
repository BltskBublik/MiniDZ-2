namespace Zoo.Domain.ValueObjects;

// Базовый класс, реализующий семантику Value Object из DDD
public abstract record ValueObject;
