namespace Zoo.Application.Services;

public class ZooStatistics
{
    public int TotalAnimals   { get; set; }
    public int FreeEnclosures { get; set; }
}